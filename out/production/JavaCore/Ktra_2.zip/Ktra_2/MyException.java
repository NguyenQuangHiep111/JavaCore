package Ktra_2;

public class MyException extends Exception {
    MyException(String message) {
        super(message);
    }
}
